const express = require("express");
const app = express();
const nodemailer = require("nodemailer")

const PORT = process.env.PORT || 3000;


// Middleware
app.use(express.static("public"));
app.use(express.json())

app.get("/", function(req,res){
    res.sendFile(__dirname + "/public/index.html");
});

app.post("/", function(req,res){
    console.log(req.body);

    const transporter = nodemailer.createTransport({
        service:"gmail",
        auth:{
            user:"iestorkdevelopers@gmail.com",
            pass:"qazwsxedc2020"
        }
    })

    const mailOptions = {
        from: req.body.email,
        to: "iestorkdevelopers@gmail.com",
        subject: 'Message from ' + req.body.name + ": " + req.body.subject,
        text:req.body.message
    };
    transporter.sendMail(mailOptions, function(error,info){
        if(error){
            console.log(error);
            res.send(error);
        }else{
            console.log("Email sent:" + info.response);
            res.send("success")
        }
    });
});
app.listen(PORT,function(){
    console.log("Server is working!");
});