const express = require("express");
const bodyParser = require("body-parser");
const request = require("request");
const https = require("https");
const app = express();

const PORT = process.env.PORT || 3000;


// Middleware
app.use(express.static("public"));
app.use(express.json())

app.get("/", function(req,res){
    res.sendFile(__dirname + "/public/index.html");
});

app.post("/", function(req,res){
    const formName = req.body.name;
    const formEmail = req.body.email;
    const formSubject = req.body.subject;
    const formMessage = req.body.message;
    const data = {
        members:[
            {
                email_address: formEmail,
                status: "subscribed",
                merge_fields:{
                    FNAME: formName,
                    SUBJECT: formSubject,
                    MESSAGE: formMessage
                }
            }
        ]
    };
    const jsonData = JSON.stringify(data);

    const url = "https://us6.api.mailchimp.com/3.0/lists/4ea3a70f27";

    const options = {
        method: "POST",
        auth: "bohirrahimov:de11ff024ed5e7a2f04537f1eae66bd0-us6"
    }

    const request = https.request(url, options, function(response){
        response.on("data", function(data){
            if(response.statusCode === 200){
            res.send("success");
            }else(
                res.send("There seems to be a problem!")
            )
        });
    });

    request.write(jsonData);
    request.end();
});


app.listen(PORT,function(){
    console.log("Server is working!");
});

//API KEY
// de11ff024ed5e7a2f04537f1eae66bd0-us6
// Unique ID
// 4ea3a70f27