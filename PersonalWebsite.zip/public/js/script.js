$(document).ready(function(){
    $(window).scroll(function(){
        if(this.scrollY > 20){
            $('.navbar').addClass('sticky')
        }else{
            $(".navbar").removeClass("sticky")
        }
        if(this.scrollY > 500){
            $('.scroll-up-btn').addClass('show')
        }else{
            $('.scroll-up-btn').removeClass('show')
        }
    })

    // slide up btn
    $(".scroll-up-btn").click(function(){
        $("html").animate({scrollTop:0});
    });

    //typing animation
    var typed = new Typed(".typing",{
        strings:["Front-End Developer", "Back-End Developer", "Wordpress Developer"],
        typeSpeed: 100,
        backSpeed:60,
        loop:true
    });
    var typed2 = new Typed(".typing-2",{
        strings:["Front-End Developer", "Back-End Developer", "Wordpress Developer"],
        typeSpeed: 100,
        backSpeed:60,
        loop:true
    });
    // toggle menu/navbar script

});
$(".menu-btn").click(function(){
    $(".navbar .menu").toggleClass("active");
    $(".menu-btn i").toggleClass("active");
});
//Contact Form
const contactForm = document.querySelector(".contact-form");
let name = document.getElementById("name");
let email = document.getElementById("email");
let subject = document.getElementById("subject");
let message = document.getElementById("message");

contactForm.addEventListener("submit", (e)=>{
    e.preventDefault();

    let formData = {
        name: name.value,
        email:email.value,
        subject: subject.value,
        message:message.value
    }
    let xhr = new XMLHttpRequest();
    xhr.open("POST","/");
    xhr.setRequestHeader('content-type','application/json');
    xhr.onload = function(){
        console.log("Checkpont1");
        console.log(xhr.responseText);
        if(xhr.responseText == "success"){
            alert("Message sent successfully!");
            name.value ="";
            email.value ="";
            subject.value ="";
            message.value ="";
        }else{
            alert("Something went wrong!")
        }
    }
    xhr.send(JSON.stringify(formData));
});
